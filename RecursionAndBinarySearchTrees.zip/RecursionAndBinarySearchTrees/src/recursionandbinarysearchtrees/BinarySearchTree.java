package recursionandbinarysearchtrees;

import java.util.Scanner;

////////////////////////////////////////////////////////////////////////
/**
* HW5
*
*   @author Kikki Beltz
*   @version November 2018
*/
////////////////////////////////////////////////////////////////////////
/**
 * Generic class that implements a binary search tree, building upon the 
 * existing BinaryTree class.
 *   @param <E> 
 * 
 *   @author Dave Reed 
 *   @version 10/9/18
 */
public class BinarySearchTree<E extends Comparable<? super E>> extends BinaryTree<E> {

    /**
     * Constructs an empty binary search tree.  NOTE: this constructor is not
     * necessary, since super() would be called automatically.
     */
    public BinarySearchTree() {
        super();
    }

    /**
     * Overrides the super.add method to add according to the BST property.
     *   @param value the value to be added to the tree
     */
    public void add(E value) {
        this.root = this.add(this.root, value);
    }
    private TreeNode<E> add(TreeNode<E> current, E value) {
        if (current == null) {
            return new TreeNode<E>(value, null, null);
        }

        if (value.compareTo(current.getData()) <= 0) {
            current.setLeft(this.add(current.getLeft(), value));
        }
        else {
            current.setRight(this.add(current.getRight(), value));
        }
        return current;
    }

    /**
     * Overrides the super.contains method to take advantage of binary search.
     *   @param value the value to be searched for
     *   @return true if that value is in the tree, otherwise false
     */
    public boolean contains(E value) {
        return this.contains(this.root, value);
    }
    private boolean contains(TreeNode<E> current, E value) {
        if (current == null) {
            return false;
        }
        else if (value.equals(current.getData())) {
            return true;
        }
        else if (value.compareTo(current.getData()) < 0) {
            return this.contains(current.getLeft(), value);
        }
        else {
            return this.contains(current.getRight(), value);
        }
    }

    public E max() {
        TreeNode<E> current = this.root;
        while (current.getRight() != null) {
            current = current.getRight();
        }
        return current.getData();
    }

    ////////////////////////////////////////////////////////////////////////////
    
    ////////////////////////////////////////////////////////////////////////////
    /**
    * HW5
    *
    *   @author Kikki Beltz
    *   @version November 2018
    */
    ////////////////////////////////////////////////////////////////////////////
    
    /**
     * Calculates the average search cost by dividing the weight of the tree by
     * the number of nodes in the tree
     * @return the value of the average search cost of the binary search tree
     */
    public double averageSearchCost() {
        if(this.size() == 0) {
            return 0;
        } else {
            return (double) this.weight()/this.size();            
        }
    }
    
    public static void main(String[] args) {
        BinarySearchTree<Integer> tree = new BinarySearchTree<Integer>();
        tree.add(7);
        tree.add(2);
        tree.add(12);
        tree.add(1);
        tree.add(5);
        tree.add(6);
        tree.add(99);
        tree.add(88);

        //System.out.println(tree);
        //System.out.println("size = " + tree.size());
        //System.out.println(tree.contains(2) + " " + tree.contains(5)
                                            //+ " " + tree.contains(8));

        tree.remove(2);
        //System.out.println(tree);
        //System.out.println("size = " + tree.size());
        //System.out.println(tree.contains(2) + " " + tree.contains(5)
                                            //+ " " + tree.contains(8));
        
        //System.out.println("max value = " + tree.max());
        
        ////////////////////////////////////////////////////////////////////////
        /**
        * HW5
        *
        *   @author Kikki Beltz
        *   @version November 2018
        */
        ////////////////////////////////////////////////////////////////////////
        System.out.println("#1.\n");
        BinarySearchTree<Double> newTree = new BinarySearchTree<Double>();
        // Empty Tree
        System.out.println(newTree.toString());
        System.out.println(newTree.weight());
        System.out.println(newTree.height());
        System.out.println(newTree.size());
        System.out.println(newTree.averageSearchCost());
        // Add 10 Nodes
        for(int i=1; i<=10; i++) {
            newTree.add(Math.random());
        }
        // Non-Empty Tree
        System.out.println(newTree.toString());
        System.out.println(newTree.weight());
        System.out.println(newTree.height());
        System.out.println(newTree.size());
        System.out.println(newTree.averageSearchCost());
        System.out.println("\n#2.");
        // Using Scanner to get input from user
        Scanner in = new Scanner(System.in); 
        // Prompt the user for number of items to be stored (N) 
        System.out.println("\nHow many items: ");
        int n = in.nextInt(); 
        // Prompt the user for the number of trees to generate (T)
        System.out.println("How many trees: ");
        int t = in.nextInt(); 
        System.out.println("Number of values to be stored: "+ n);
        System.out.println("Number of trees to generate: "+ t);
        // Generating output
        System.out.println("Generating " + t + " trees with " + n + " random values: ");
        int averageHeight = 0;
        int averageCost = 0;
        for (int j=0; j<t; j++) {
            BinarySearchTree<Double> newTree2 = new BinarySearchTree<Double>();
            for(int k=0; k<n; k++) {
                newTree2.add(Math.random());
            }
            averageHeight += newTree2.height();
            averageCost += newTree2.averageSearchCost();
        }
        System.out.println("Minimum possible height: " + (Math.log10(n+1))/(Math.log10(2)));
        System.out.println("Average tree height: " + (double) averageHeight/t);
        System.out.println("Average search cost: " + (double) averageCost/t);
        System.out.println("\n#3.\n");
        int o = 1000;
        System.out.println("===================================================================");
        System.out.println("|Number of Values(N)|Min Height|Average Height|Average Search Cost|");
        for(int p = 0; p<6; p++) {
            int averageHeight3 = 0;
            int averageCost3 = 0;
            double min = 0;
            for (int l=0; l<1000; l++) {
                BinarySearchTree<Double> newTree3 = new BinarySearchTree<Double>();
                for(int m=0; m<o; m++) {
                    newTree3.add(Math.random());
                }
                averageHeight3 += newTree3.height();
                averageCost3 += newTree3.averageSearchCost();  
            }
            min = (Math.log10(o+1))/(Math.log10(2));
            System.out.println("|   " + o + "  | " + min + " |    " + (double) averageHeight3/1000 + "     |      " + (double) averageCost3/1000 + "       |");
            o *= 2;
        }
        System.out.println("===================================================================");
        System.out.println("Do your statistics support the claims that the "
                + "average height and cost of searching a randomly constructed "
                + "binary search tree are both O(log N)?");
        System.out.println("Yes.");
        System.out.println("Justify your answer.");
        System.out.println("The minimum possible height of the tree is\n"
                + "log2(N+1). The average search cost is slightly larger than the\n"
                + "minimum height, which is approximately log2(N) plus a constant.\n"
                + "Likewise, while the average search cost is larger than both the\n"
                + "minimum height and the average height, it is roughly equivalent\n"
                + "to 2.3 times the minimum height, or 2.3 * log2(N), or log2(N)\n"
                + "times a constant. Constants can be disregarded in both cases,\n"
                + "which leaves log2(N) for both the average height and the average\n"
                + "search cost.");     
    }
}
