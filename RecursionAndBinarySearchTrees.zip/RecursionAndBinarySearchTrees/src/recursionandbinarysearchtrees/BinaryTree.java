package recursionandbinarysearchtrees;

import static java.lang.Integer.max;

////////////////////////////////////////////////////////////////////////
/**
* HW5
*
*   @author Kikki Beltz
*   @version November 2018
*/
////////////////////////////////////////////////////////////////////////
/**
 * Generic class that implements a binary tree structure.
 *   @param <E> 
 *
 *   @author Dave Reed
 *   @version 10/9/18
 */
public class BinaryTree<E> {
    protected TreeNode<E> root;

    /**
     * Constructs an empty binary tree.
     */
    public BinaryTree() {
        this.root = null;
    }

    /**
     * Adds a value to the binary tree (at the shallowest possible location)
     *   @param value the value to be added
     */
    public void add(E value) {
        this.root = this.add(this.root, value);
    }
    private TreeNode<E> add(TreeNode<E> current, E value) {
        if (current == null) {
            current = new TreeNode<E>(value, null, null);
        }
        else if (this.size(current.getLeft()) <= this.size(current.getRight())) {
            current.setLeft(this.add(current.getLeft(), value));
        }
        else {
            current.setRight(this.add(current.getRight(), value));
        }
        return current;
    }

    /**
     * Determines the size of the binary tree
     *   @return the size (number of nodes in the tree)
     */
    public int size() {
        return this.size(this.root);
    }
    private int size(TreeNode<E> current) {
        if (current == null) {
            return 0;
        }
        else {
            return this.size(current.getLeft()) +
                   this.size(current.getRight()) + 1;
        }
    }

    /**
     * Determines whether the tree contains a particular value.
     *   @param value the value to be searched for
     *   @return true if value is in the tree, otherwise false
     */
    public boolean contains(E value) {
        return this.contains(this.root, value);
    }
    private  boolean contains(TreeNode<E> current, E value) {
        if (current == null) {
            return false;
        }
        else {
            return value.equals(current.getData()) ||
                   this.contains(current.getLeft(), value) ||
                   this.contains(current.getRight(), value);
        }
    }

    /**
     * Removes one occurrence of the specified value.
     *   @param value the value to be removed
     *   @return true if the value was found and removed, else false
     */
    public boolean remove(E value) {
        if (!this.contains(value)) {
            return false;
        }
        else {
            this.root = this.remove(this.root, value);
            return true;
        }
    }
    private TreeNode<E> remove(TreeNode<E> current, E value) {
        if (value.equals(current.getData())) {
            if (current.getLeft() == null) {
                current = current.getRight();
            }
            else {
                TreeNode<E> righty = current.getLeft();
                while (righty.getRight() != null) {
                    righty = righty.getRight();
                }
                current.setData(righty.getData());
                current.setLeft(this.remove(current.getLeft(), current.getData()));
            }
        }
        else if (this.contains(current.getLeft(), value)) {
            current.setLeft(this.remove(current.getLeft(), value));
        }
        else {
            current.setRight(this.remove(current.getRight(), value));
        }
        return current;
    }

    /**
     * Converts the tree to a String using an inorder traversal.
     * @return the String representation of the tree.
     */
    public String toString() {
        if (this.root == null) {
            return "[]";
        }

        String recStr = this.toString(this.root);
        return "[" + recStr.substring(0,recStr.length()-1) + "]";
    }
    private String toString(TreeNode<E> current) {
        if (current ==  null) {
            return "";
        }

        return this.toString(current.getLeft()) +
               current.getData().toString() + "," +
               this.toString(current.getRight());
    }

    //////////////////////////////////////////////////////////////////////

    protected class TreeNode<E> {
        private E data;
        private TreeNode<E> left;
        private TreeNode<E> right;

        public TreeNode(E d, TreeNode<E> l, TreeNode<E> r) {
            this.data = d;
            this.left = l;
            this.right = r;
        }

        public E getData() {
            return this.data;
        }

        public TreeNode<E> getLeft() {
            return this.left;
        }

        public TreeNode<E> getRight() {
            return this.right;
        }

        public void setData(E newData) {
            this.data = newData;
        }

        public void setLeft(TreeNode<E> newLeft) {
            this.left = newLeft;
        }

        public void setRight(TreeNode<E> newRight) {
            this.right = newRight;
        }
    }
    
    
    ////////////////////////////////////////////////////////////////////////////
    /**
    * HW5
    *
    *   @author Kikki Beltz
    *   @version November 2018
    */
    ////////////////////////////////////////////////////////////////////////////
    /**
     * Returns the height of the tree, i.e., the length of the longest path from 
     * the root to a leaf.
     * @return integer value of height
     */
    public int height() {
        return this.height(this.root);
    }
    /**
     * @param current is the root node for the current subtree
     * Finds the length of the longest path from root to leaf
     * @returns integer value of height
     */
    private int height(TreeNode<E> current) {
        if(current == null) {
            return 0;
        } else {
            return max(height(current.getLeft()), height(current.getRight())) + 1;
        } 
    }
    /**
     * Returns the weight of the tree, i.e., the sum of all the node depths.
     * @returns the sum of the depths of all nodes in the tree
     */
    public int weight() {
        return this.weight(this.root);
    }
    /**
     * @param current is the root node for the current subtree
     * @returns the sum of the depths of all nodes in the tree
     */    
    private int weight(TreeNode<E> current) {
        if(current == null) {
            return 0;
        } else {
            return weight(current.getLeft()) + size(current) + weight(current.getRight());
        }
    }
}